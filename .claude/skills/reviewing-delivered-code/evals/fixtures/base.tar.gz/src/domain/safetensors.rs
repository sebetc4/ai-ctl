//! A safetensors index, such as `diffusion_pytorch_model.safetensors.index.json`:
//! a model's weights split into shards, each tensor mapped to the shard that
//! holds it, read as stable-diffusion.cpp reads it.

use std::collections::BTreeSet;
use std::path::{Component, Path, PathBuf};

use anyhow::{Context, Result, bail, ensure};
use serde_json::Value;

use super::text::escape_controls;

/// The shards the index `text` names, each once: the values of its
/// `weight_map` object, which maps each tensor to its shard's path, one
/// shard at least. A shard holding a control or invisible character is
/// refused, since `doctor` prints it.
pub fn shards(text: &str) -> Result<BTreeSet<String>> {
    let index: Value = serde_json::from_str(text).context("not JSON")?;
    let Some(weight_map) = index.get("weight_map").and_then(Value::as_object) else {
        bail!("no `weight_map` object");
    };
    let mut shards = BTreeSet::new();
    for (tensor, shard) in weight_map {
        let Some(shard) = shard.as_str().filter(|shard| !shard.is_empty()) else {
            bail!("the tensor `{}` has no shard path", escape_controls(tensor));
        };
        let shown = escape_controls(shard);
        ensure!(
            shown == shard,
            "the shard `{shown}` holds a control or invisible character"
        );
        shards.insert(shown);
    }
    ensure!(!shards.is_empty(), "`weight_map` names no shard");
    Ok(shards)
}

/// Where stable-diffusion.cpp reads `shard`, named by the index at the
/// absolute path `index`: an absolute `shard` as it is, a relative one from
/// the index's directory, with `.` and `..` resolved without following
/// links.
pub fn shard_path(index: &Path, shard: &str) -> PathBuf {
    let joined = index.parent().unwrap_or(index).join(shard);
    let mut path = PathBuf::new();
    for component in joined.components() {
        match component {
            Component::CurDir => {}
            // At the root, `..` stays there, as the kernel reads it.
            Component::ParentDir => {
                path.pop();
            }
            component => path.push(component),
        }
    }
    path
}

#[cfg(test)]
mod tests {
    use super::*;

    const FIBO: &str = include_str!(
        "../../tests/fixtures/fibo-2.0-dev-72415bd0-diffusion_pytorch_model.safetensors.index.json"
    );

    fn refused(text: &str) -> String {
        format!("{:#}", shards(text).unwrap_err())
    }

    #[test]
    fn fibos_index_names_its_two_shards() {
        assert_eq!(
            shards(FIBO).unwrap(),
            BTreeSet::from([
                "diffusion_pytorch_model-00001-of-00002.safetensors".to_owned(),
                "diffusion_pytorch_model-00002-of-00002.safetensors".to_owned(),
            ])
        );
    }

    #[test]
    fn an_index_without_a_weight_map_of_shards_is_refused() {
        assert!(refused("{").starts_with("not JSON: "), "{}", refused("{"));
        for text in ["[]", "{}", r#"{"weight_map": []}"#] {
            assert_eq!(refused(text), "no `weight_map` object", "{text}");
        }
        assert_eq!(
            refused(r#"{"weight_map": {}}"#),
            "`weight_map` names no shard"
        );
        assert_eq!(
            refused(r#"{"weight_map": {"a.weight": "a.safetensors", "b.weight": 2}}"#),
            "the tensor `b.weight` has no shard path"
        );
        assert_eq!(
            refused(r#"{"weight_map": {"a.weight": ""}}"#),
            "the tensor `a.weight` has no shard path"
        );
        assert_eq!(
            refused(r#"{"weight_map": {"a\u001bweight": null}}"#),
            "the tensor `a\\u001Bweight` has no shard path"
        );
    }

    #[test]
    fn a_shard_that_would_drive_the_terminal_is_refused() {
        assert_eq!(
            refused(r#"{"weight_map": {"a\u001b[2Jweight": "a\u001b[2J.safetensors"}}"#),
            "the shard `a\\u001B[2J.safetensors` holds a control or invisible character"
        );
        assert_eq!(
            refused(r#"{"weight_map": {"a.weight": "a\u202e.safetensors"}}"#),
            "the shard `a\\u202E.safetensors` holds a control or invisible character"
        );
    }

    #[test]
    fn a_shard_is_read_from_the_indexs_directory_unless_absolute() {
        let index = Path::new("/models/fibo/transformer/model.safetensors.index.json");
        let path = |shard| shard_path(index, shard);
        assert_eq!(
            path("model-00001.safetensors"),
            Path::new("/models/fibo/transformer/model-00001.safetensors")
        );
        assert_eq!(
            path("./shards/../model-00001.safetensors"),
            Path::new("/models/fibo/transformer/model-00001.safetensors")
        );
        assert_eq!(path("../../../../../etc/passwd"), Path::new("/etc/passwd"));
        assert_eq!(
            path("/data/model.safetensors"),
            Path::new("/data/model.safetensors")
        );
    }
}
