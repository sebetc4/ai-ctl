# Changelog — ai-ctl

## 0.2.0 — unreleased

- The v2 rebuild, on a new history with v1 archived as a bundle (roadmap `v2-rebuild`): ten commands around one declarative inventory — `init`, `doctor`, `build` with `list`, `use` and `prune`, `gateway install | config`, `up`, `down`, `status`, `logs` and `bench run | list | compare` —, a pinned llama-swap as the single gateway on `127.0.0.1:8080` and the only process that starts or stops a model.
- The fixes of its review (roadmap `v2-review-fixes`): the gateway and every backend answer only a client holding ai-ctl's key, a non-loopback `listen` needs `expose = true`, the inventory refuses unsafe values, downloads and images are pinned; the builds, the gateway's records and the bench's runs survive failures and interruptions; `doctor` from 690 to 247 ms.
- Speech and images (roadmap `audio-image-backends`): `whisper-server`, `audiocpp_server` and `sd-server` built natively by `ai-ctl build`, each patched to require ai-ctl's key, declared in the inventory as three new kinds and served by the gateway; the shipped inventory serves 13 models on four backends, used from OpenWebUI for transcription, speech, image generation and editing.
